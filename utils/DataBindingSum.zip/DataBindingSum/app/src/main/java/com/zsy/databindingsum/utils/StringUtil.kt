package com.zsy.databindingsum.utils

//object StringUtil {
//
//    fun add(value: String): String {
//        return "[$value]"
//    }
//}

val pre = "["
val suf = "]"

fun add(value: String): String {
    return pre + value + suf
}
//
//fun main() {
//    com.zsy.databindingsum.utils.add("")
//}
