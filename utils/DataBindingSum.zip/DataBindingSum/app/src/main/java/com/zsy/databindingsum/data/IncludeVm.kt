package com.zsy.databindingsum.data

class IncludeVm {
    val msg = "IncludeMsg"
}