package com.zsy.databindingsum.data

import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.Transformations
import androidx.lifecycle.ViewModel

class OwnerLdVm : ViewModel() {
    val msg = MutableLiveData<String>("ownerLdvm")

    val src = MutableLiveData(1)

    val des = Transformations.map(src) {
        "${src.value} dexs "
    }
    val sDes = Transformations.switchMap(src) {
        src
    }
}