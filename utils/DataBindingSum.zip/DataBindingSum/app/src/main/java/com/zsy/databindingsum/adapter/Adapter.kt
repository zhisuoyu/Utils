package com.zsy.databindingsum.adapter

import android.widget.TextView
import androidx.databinding.BindingAdapter

@BindingAdapter("brText")
fun setBrText(tv: TextView, text: String) {
    tv.text = text
}