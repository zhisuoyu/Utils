package com.zsy.databindingsum.event

import android.util.Log
import android.view.View

object EventHandler {

    val TAG = "EventHandler"

    fun emptyLg() {
        Log.i(TAG, "emptyLg")
    }

    fun viewLg(view: View) {
        Log.i(TAG, "viewLg${view}")
    }

    fun paramLg(param: String) {
        Log.i(TAG, param)
    }


}