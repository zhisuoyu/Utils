package com.zsy.databindingsum.data

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel

class MainViewMode : ViewModel() {

    private val name = MutableLiveData<String>().apply { value = "" }
}