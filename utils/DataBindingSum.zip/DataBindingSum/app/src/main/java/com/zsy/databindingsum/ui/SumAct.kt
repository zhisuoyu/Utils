package com.zsy.databindingsum.ui

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.databinding.DataBindingUtil
import com.zsy.databindingsum.R
import com.zsy.databindingsum.databinding.ActSumBinding

class SumAct : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val binding = DataBindingUtil.setContentView<ActSumBinding>(
            this, R.layout.act_sum
        )
    }
}