//package com.zsy.databindingsum.utils
//
//class StringUtils {
//    companion object {
//        fun addBreakets(param: String): String {
//            return "[$param]"
//        }
//    }
//}
