package com.zsy.databindingsum.ui

import android.os.Bundle
import android.util.Log
import androidx.appcompat.app.AppCompatActivity
import androidx.databinding.DataBindingUtil
import com.zsy.databindingsum.R
import com.zsy.databindingsum.data.TwoWayVm
import com.zsy.databindingsum.databinding.ActTwoWayBinding
import com.zsy.databindingsum.utils.Converter

class TwoWayAct : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val binding = DataBindingUtil.setContentView<ActTwoWayBinding>(this, R.layout.act_two_way)
        binding.converter = Converter()
        val vm = TwoWayVm()
        binding.vm = vm
//        binding.btnLg.setOnClickListener {
//            Log.i("TWOWAY", "" + vm.dt.value)
//        }
//        binding.btnSet.setOnClickListener {
//            vm.dt.value = System.currentTimeMillis()
//        }
        binding.lifecycleOwner = this
    }

}