package com.zsy.databindingsum.data

class OwnerData {
    var msg = "ownerMsg"
}