package com.zsy.databindingsum.ui

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.databinding.DataBindingUtil
import com.zsy.databindingsum.R
import com.zsy.databindingsum.event.EventHandler
import com.zsy.databindingsum.databinding.ActEventBinding

class EventAct : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val binding = DataBindingUtil.setContentView<ActEventBinding>(
            this, R.layout.act_event
        )
        binding.handler = EventHandler
        binding.param = "Pm"
    }
}