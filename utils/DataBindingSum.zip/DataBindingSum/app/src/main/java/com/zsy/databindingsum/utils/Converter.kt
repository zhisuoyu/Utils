package com.zsy.databindingsum.utils

import android.util.Log
import androidx.databinding.InverseMethod
import java.text.SimpleDateFormat
import java.util.*


class Converter {

    //    companion object {
    private val SDF = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.ENGLISH)

    fun formatDt(ms: Long): String {
        val dt = SDF.format(ms)
        Log.i("CONVERTER", dt)
        return dt
    }

    @InverseMethod("formatDt")
    fun inFormatDt(dt: String): Long {
        val date = SDF.parse(dt)
        return date.time
    }
//    }
}