package com.zsy.databindingsum.data

import androidx.lifecycle.ViewModel

class OwnerVm : ViewModel() {
    var msg = "ownerVm"
}