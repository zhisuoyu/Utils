package com.zsy.databindingsum.ui

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.databinding.DataBindingUtil
import com.zsy.databindingsum.R
import com.zsy.databindingsum.data.OwnerData
import com.zsy.databindingsum.databinding.ActAdapterBinding

class AdapterAct : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val binding = DataBindingUtil.setContentView<ActAdapterBinding>(this, R.layout.act_adapter)
        binding.data = OwnerData()
    }
}