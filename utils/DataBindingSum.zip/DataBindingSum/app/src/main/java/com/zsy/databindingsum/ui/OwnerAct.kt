package com.zsy.databindingsum.ui

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.databinding.DataBindingUtil
import com.zsy.databindingsum.R
import com.zsy.databindingsum.data.OwnerData
import com.zsy.databindingsum.data.OwnerLd
import com.zsy.databindingsum.data.OwnerLdVm
import com.zsy.databindingsum.data.OwnerVm
import com.zsy.databindingsum.databinding.ActOwnerBinding


/**
 * 1.LiveData + lifecycleOwner 修改数据自动更新UI(在生成的ViewDataBinding子类中，会判断数据绑定数据类型是否LiveData,若是则注册绑定)
 * 2.ViewModel + ViewModelProviders 复用ViewModel，屏幕旋转ViewModel不回收
 */
class OwnerAct : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val binding = DataBindingUtil.setContentView<ActOwnerBinding>(this, R.layout.act_owner)

        val data = OwnerData()
        val ld = OwnerLd()
        val vm = OwnerVm()
        val ldvm = OwnerLdVm()
        binding.data = data
        binding.ld = ld
        binding.vm = vm
        binding.ldvm = ldvm

        binding.btnData.setOnClickListener {
            data.msg = "new owner data"
        }
        binding.btnLd.setOnClickListener {
            ld.msg.value = "new owner ld"
        }
        binding.btnVm.setOnClickListener {
            vm.msg = "new owner msg"
        }
        binding.btnLdvm.setOnClickListener {
            ldvm.msg.value = "new owner ldvm"
        }
        binding.btnTsldvm.setOnClickListener {
            ldvm.src.value = 2
        }
        binding.lifecycleOwner = this
    }
}