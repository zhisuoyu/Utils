package com.zsy.databindingsum.ui

import android.os.Bundle
import android.widget.LinearLayout
import androidx.appcompat.app.AppCompatActivity
import com.zsy.databindingsum.R
import com.zsy.databindingsum.extension.addButton
import org.jetbrains.anko.intentFor

class MainAct : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.act_main)
        val ll = findViewById<LinearLayout>(R.id.ll_main)

        ll.addButton("Owner") {
            startActivity(intentFor<OwnerAct>())
        }

        ll.addButton("Event") {
            startActivity(intentFor<EventAct>())
        }

        ll.addButton("TwoWay") {
            startActivity(intentFor<TwoWayAct>())
        }

        ll.addButton("Include") {
            startActivity(intentFor<IncludeAct>())
        }

        ll.addButton("Adapter") {
            startActivity(intentFor<AdapterAct>())
        }

        ll.addButton("Sum") {
            //            startActivity(intentFor<>())
        }
//        findViewById<Button>(R.id.btn_empty).setOnClickListener {
//            val name = MutableLiveData<String>("").apply { value = "hello" }
//            Log.i("TAG", name.value)
//        }
//        findViewById<Button>(R.id.btn_value).setOnClickListener {
//            val name = MutableLiveData<String>("hello").
//            Log.i("TAG", name.value)
//            val l = MutableLiveData<String>()
//        }
    }

}