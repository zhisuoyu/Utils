package com.zsy.databindingsum.ui

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.databinding.DataBindingUtil
import com.zsy.databindingsum.R
import com.zsy.databindingsum.data.IncludeVm
import com.zsy.databindingsum.databinding.ActIncludeBinding

class IncludeAct : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val binding = DataBindingUtil.setContentView<ActIncludeBinding>(
            this,
            R.layout.act_include
        )

        binding.vm = IncludeVm()
    }

}