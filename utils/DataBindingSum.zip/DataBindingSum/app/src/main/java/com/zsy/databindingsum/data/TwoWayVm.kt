package com.zsy.databindingsum.data

import android.view.View
import androidx.lifecycle.ViewModel

class TwoWayVm : ViewModel() {

//    var dt = MutableLiveData(System.currentTimeMillis())

//    var msg = object::MutableLiveData("msg")
//    {
//
//    }

    fun t(view: View) {
        val lsn =object :Lsn {
            override fun click() {
                TODO("not implemented") //To change body of created functions use File | Settings | File Templates.
            }
        }

//        view.setOnClickListener(View.OnClickListener {  })
    }

    interface Lsn {
        fun click()
    }

}
