package com.zsy.databindingsum.data

import androidx.lifecycle.MutableLiveData

class OwnerLd {
    val msg = MutableLiveData<String>("ownerLd")
}