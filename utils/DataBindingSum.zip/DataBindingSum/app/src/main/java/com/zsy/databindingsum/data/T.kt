package com.zsy.databindingsum.data

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData

class T {

    internal var data: LiveData<String> = object : MutableLiveData<String>("") {
        override fun setValue(value: String) {
            super.setValue(value)
        }
    }
}
